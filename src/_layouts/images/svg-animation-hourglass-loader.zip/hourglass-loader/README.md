# Hourglass loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/madetoday/pen/MYxYeo](https://codepen.io/madetoday/pen/MYxYeo).

Pure SVG infinite loader 

design: https://dribbble.com/shots/1503949-Hourglass-loader
