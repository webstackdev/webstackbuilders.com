# Responsive Huggy Laser Panda Factory

A Pen created on CodePen.io. Original URL: [https://codepen.io/sdras/pen/waXKPw](https://codepen.io/sdras/pen/waXKPw).

Click the hotspots to make Huggy Laser Pandas. The factory is animated on click. The animation was made in sections to be reassembled for responsive. Made with GSAP + SVG.

Article on how this was made:
http://davidwalsh.name/gsap-svg-responsive-animation

 (my original Huggy Laser Panda Pen is here: http://codepen.io/sdras/pen/MweKRb)