# All Devices in SVG

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/WvJMXP](https://codepen.io/chrisgannon/pen/WvJMXP).

A morphing animation to represent different devices.
If you like this you can buy it [here](https://gannon.tv/products/morphing-devices)