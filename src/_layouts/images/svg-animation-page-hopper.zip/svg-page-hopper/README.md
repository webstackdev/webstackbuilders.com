# SVG Page Hopper

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/xVOjZq](https://codepen.io/chrisgannon/pen/xVOjZq).

This is a slight variation on a pagination method I've designed for a client.

I've made it so it's simple to add as many circles (pages) as you need and they can be any distance apart and it doesn't use any filters so performance is good.