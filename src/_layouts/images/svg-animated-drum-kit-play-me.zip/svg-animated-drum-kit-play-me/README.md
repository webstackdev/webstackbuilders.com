# SVG Animated Drum Kit (Play Me!) 🥁

A Pen created on CodePen.io. Original URL: [https://codepen.io/iamjoshellis/pen/KVdQqm](https://codepen.io/iamjoshellis/pen/KVdQqm).

Rock out with this interactive svg animation, click, tap, or keys to play! Part of my [Pen's of Rock!](http://codepen.io/collection/APoYVq/) collection. Drawn in adobe illustrator, animated with greensock. Turn your speakers up for html audio elements in your ears!
Weird bounding box appears when tapped on mobile, any ideas?