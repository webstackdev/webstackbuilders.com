# CSS/SVG Lines App Concept

A Pen created on CodePen.io. Original URL: [https://codepen.io/davidkpiano/pen/zqNJRY](https://codepen.io/davidkpiano/pen/zqNJRY).

A CSS and SVG-only rework of an original Dribbble shot by [Jakub Antalík](a href="https://dribbble.com/shots/2580453-Health-App-Login). Works in Chrome and Firefox.