# SVG Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/mohebifar/pen/KwdeMz](https://codepen.io/mohebifar/pen/KwdeMz).

A clock made with SVG which shows current time and uses SVG's animation functionality.