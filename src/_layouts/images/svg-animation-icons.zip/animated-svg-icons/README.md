# Animated SVG icons

A Pen created on CodePen.io. Original URL: [https://codepen.io/luruke/pen/mbnkA](https://codepen.io/luruke/pen/mbnkA).

Hi All!
Here is some nice animated svg icons made for the website rollstudio.co.uk.
GSAP (http://greensock.com/gsap) is used in order to build the animation timeline.

The Icons are made by James White.

Check out them on http://rollstudio.co.uk/about/ !

Feedback is welcome! ;)