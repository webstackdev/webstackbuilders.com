# SVG animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/thiennhat/pen/BNByzJ](https://codepen.io/thiennhat/pen/BNByzJ).

illustration Adorable Flat Workspaces of Nasti Funny (https://www.behance.net/gallery/25243191/FREE-Adorable-Flat-Workspaces)<br/>
Gsap TweenMax(http://greensock.com/docs/#/HTML5/GSAP/TweenMax/)